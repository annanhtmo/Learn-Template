<?php	
	session_start();	
	$server = "localhost";
	$username = "root";
	$pass = "";
	$konek = mysql_connect($server,$username,$pass);
	if($konek){
		//echo "konek";
		$db = "pencatatan";
		$sdb = mysql_select_db($db);
		if($db){
			//echo "db ada";
		}else{
			//echo "tidak ada";
		}
	}
	else{
		echo "tidak";
	}
?>

	<script type="text/javascript">
//<![CDATA[
function showclock (){
var digital = new Date();
var hours=digital.getHours();
var minutes=digital.getMinutes();
var seconds=digital.getSeconds();
var dn='AM';
if (hours>12) {
dn='PM';
hours=hours-12;
}
if (hours==0) hours=12;
if (minutes<=9) minutes='0'+minutes;
if (seconds<=9) seconds='0'+seconds;

miReloj='<b><span style="color:#fff;font-size:15;">'
+ hours + ' : ' + '</span>  <span style="color:#fff;font-size:15px;">'
+ minutes + ' :' + '</span>  <span style="color:#fff;font-size:15px;">'
+ seconds + '</span></b><span style="color:#fff;font-size:15px;margin-left:3px;">'
+ dn + '</span>';
document.getElementById('time').innerHTML=miReloj;
//
setTimeout('showclock()',1000);
}

//]]>
</script>