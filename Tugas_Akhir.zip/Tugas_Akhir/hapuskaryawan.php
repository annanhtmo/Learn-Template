<?php
include "db_connect.php";
extract($_GET);
$kueli='delete from karyawan where nik="'.$nik.'"';
$query=mysql_query($kueli);
if ($query){
	$_SESSION['hapuskaryawan'] = 1;
	header('Location:Signup_karyawan.php');
}
else {
	echo "gagal";		
	die(mysql_error());
}



?>
