<!DOCTYPE html>

<html lang="en"> 

	<head>
			<link href="style.css" rel="stylesheet" > 
			 <link href="lib/w3.css" rel="stylesheet">
			<link rel=”icon” type=”image/png” href=”logo.png”>
		  	<title>TAP Barcode</title> 
		  	<!--<script type="text/javascript">
//<![CDATA[
function showclock (){
var digital = new Date();
var hours=digital.getDate();
var minutes=digital.getMinutes();
var seconds=digital.getSeconds();
var dn='AM';
if (hours>12) {
dn='PM';
hours=hours-12;
}
if (hours==0) hours=12;
if (minutes<=9) minutes='0'+minutes;
if (seconds<=9) seconds='0'+seconds;

miReloj='<b><span style="color:#fff;font-size:15;">'
+ hours + ' : ' + '</span>  <span style="color:#fff;font-size:15px;">'
+ minutes + ' :' + '</span>  <span style="color:#fff;font-size:15px;">'
+ seconds + '</span></b><span style="color:#fff;font-size:15px;margin-left:3px;">'
+ dn + '</span>';
document.getElementById('time').innerHTML=miReloj;
//
setTimeout('showclock()',1000);
}

//]]>
</script> -->

	<script type="text/javascript" src="lib/DataTables/media/js/jquery.js" ></script>
		<!-- <script type="text/javascript" src="DataTables/media/js/jquery.dataTables.js" ></script> -->
		<link rel="stylesheet" type="text/css" href="lib/DataTables/media/css/jquery.dataTables.min.css">
		<link rel="stylesheet" type="text/css" href="lib/DataTables/media/css/dataTables.bootstrap.min.css">
		<link rel="stylesheet" type="text/css" f="lib/DataTables/extensions/Buttons/css/buttons.dataTables.min.css">
		<!--Script Online For All Function -->
		<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js" ></script>

	</head>
		<header>
			<ul>
	<li><img src="battery.png"></li>			
	<li><a class="active" href="index.php">Absensi</a></li>
  	<li><a href="Signup_karyawan.php">Daftar</a></li>
	<!--<li><a href="q.php">kontrol</a></li> -->
  	<!--<li><a href="Datakaryawan.php">Data</a></li> -->
  	<li><a href="makan.php">Makan</a></li>
  		<li id="time" style="float:right;padding-right:5%"></li>
  		</ul>
  		</header>
  	
<body onLoad="showclock()">
	
	<div>
		<?php 
		if (!empty($_SESSION['gagal_absen']) && $_SESSION['gagal_absen']==1) {
			?> 
			<script type="text/javascript">
				alert("Anda Pulang aja mending");
			</script>
			<!--<script>
				alert("Anda TERLAMBAT ");
			</script> -->
	<?php 
		echo $_SESSION['gagal_absen'];
		$_SESSION['gagal_absen']=0;
		echo $_SESSION['gagal_absen'];

	}
	?>
		<br>
		<br>
		<h3><center>Selamat datang </h3>
		<h4><center>TAP KARTU ANDA DI BARCODE SCANNER</h4>
		<form action="absen_karyawan.php" method="get">
			<table>
				<tr>
					<td><center><input type="text" name="nik" placeholder ="NIK" autofocus="autofocus" required>
				</tr>
				<tr>
				
					<td><center><input type="submit" name="login" value="Log In"></cemter></td>
				</tr>
	</div>
			</table>	
		</form>
		<div class="panel-heading">
				<center>
				 PT GS Battery
				 <br/>
				 Kawasan Industri Surya Cipta Swadaya
				 <br/>
				 JL. Surya Utama Kav. I3-I4 Ciampel - Karawang
				</center>
			</div>
</body>
</html>
