<html><head>
<title>Input Data untuk makan </title>
</head><body>
<h2>Data Karyawan Baru</h2>
<form action="savekaryawan.php" method="POST">
<table>
<tr>
<td>NAMA</td>
<td>: <input type="text" name="Nama" size="30"></td>
</tr>
<tr>
<td>ID</td>
<td>: <input type="text" name="ID" size="10"></td>
</tr>
<td colspan=2><input type="submit" value="Kirim"></td>
</tr></table></form>
</body></html>