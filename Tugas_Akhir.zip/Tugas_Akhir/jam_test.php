<?php
	date_default_timezone_set("Asia/Jakarta"); 
	$dateTime = new DateTime($ThatTime);

	echo $dateTime;


		if ($dateTime == 6) {
		 	echo"enam";
	 	}
	 	elseif ($dateTime > 7) {
	 		echo " kuraang";
	 	}
	
		
?>
