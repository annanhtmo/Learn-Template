 <?php 
 		include 'db_connect.php';
          $query = 'SELECT * FROM  WHERE nama_ruangan= "kantin"';
          $result = mysql_query($query);
            if ($result) {
              if(mysql_num_rows($result)){
                $row=mysql_fetch_assoc($result);
                echo "KAPASITAS = ".$row['jumlah'];
              }
            }

          ?>