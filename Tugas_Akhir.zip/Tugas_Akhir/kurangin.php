<?php
	require_once 'db_connect.php';

	$krng = $_GET['krng'];
	$jumlahbaru;

	$query = 'SELECT jumlah FROM kapasitas WHERE nama_ruangan = "kantin"';
	$result = mysql_query($query);
	if($result)
	{
		if (mysql_num_rows($result))
		{
			$row = mysql_fetch_assoc($result);
			if ($row['jumlah'] >= 1)
			{
				$jumlahbaru = $row['jumlah'] - $krng;

				$query = 'UPDATE kapasitas SET jumlah = '.$jumlahbaru.' WHERE nama_ruangan = "kantin"';

				$result = mysql_query($query);
				if ($result)
				{
					echo 'berhasil';
				}
				else
				{
					die(mysql_error());
				}
			}
			else
			{
				//let the storm rage on~

				//cold never bother me anyway~
				echo 'udah abis, gak bisa dikurangin lagi bro';
			}
			
		}
		else
		{
			echo 'ditemukan >1 record. integritas data diragukan';
		}
	}
	else
	{
		die(mysql_error());
	}

?>